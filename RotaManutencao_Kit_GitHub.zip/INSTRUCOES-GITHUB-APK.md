# Instalar o RotaManutenção no Android: compilação pelo GitHub

O projeto está pronto para uma compilação de teste; ainda não há APK validado.

## Pelo navegador do Android (sem computador)

1. Abra `https://github.com/higordomin/Rotamanutencao` estando conectado à sua conta GitHub. Para facilitar a interface, ative **Versão para computador** no menu do navegador, se necessário.
2. Em **Add file → Upload files**, selecione o arquivo **RotaManutencao_Projeto_Android.zip** (envie o ZIP **sem descompactar**) e confirme em **Commit changes**.
3. Volte à raiz do repositório. Em **Add file → Create new file**, no nome do arquivo escreva **`.github/workflows/compilar-apk.yml`** (inclusive o ponto inicial). O GitHub cria as pastas a partir das barras.
4. Abra o arquivo **compilar-apk.yml** deste pacote, copie **todo o conteúdo** e cole na caixa de edição do GitHub. Clique em **Commit changes**. Não inclua marcas de formatação, apenas o YAML.
5. Abra **Actions → Compilar APK - RotaManutencao**. O processo deverá executar automaticamente com o envio do workflow; caso contrário, use **Run workflow → Run workflow**.
6. Aguarde até a execução terminar com o símbolo verde. Abra a execução e, na seção **Artifacts**, baixe **RotaManutencao-APK**. O GitHub entregará um arquivo ZIP: extraia-o e encontre **app-debug.apk**.
7. No Android, abra **app-debug.apk**, autorize instalar apps a partir do aplicativo que abriu o arquivo, se solicitado, e conclua a instalação.

**Se o build ficar vermelho**, abra a execução, selecione **Compilar Android offline** e copie a mensagem de erro para enviar ao ChatGPT. O APK não está garantido até o GitHub Actions compilar com sucesso.

## Privacidade e dados

- O aplicativo não tem login, internet, contas nem sincronização; dados de OS/rotas ficam no armazenamento do app no dispositivo.
- O **repositório GitHub atualmente é público**. O código-fonte não deve incluir dados reais de máquinas, operações ou informações internas da empresa. Você pode alterar o repositório para privado em **Settings → General → Danger Zone → Change repository visibility**.
- O arquivo gerado é um APK **debug** para instalação/testes particulares, não uma versão para distribuição na Play Store.
- Antes de desinstalar o app ou limpar seus dados, exporte o backup JSON.
- As notificações são um resumo diário local e podem sofrer atraso devido às limitações de bateria do Android.
